<?php

////////////////////////////////////////////////////////////////////////////////
// 2CO Order Notify
// Last modified: 08.12.2010
////////////////////////////////////////////////////////////////////////////////

// *** Make sure the file isn't accessed directly
defined('APPHP_EXEC') or die('Restricted Access');
//--------------------------------------------------------------------------

draw_important_message(_NOT_AUTHORIZED);

?>