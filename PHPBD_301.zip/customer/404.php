<?php
/**
* @project ApPHP Business Directory
* @copyright (c) 2012 ApPHP
* @author ApPHP <info@apphp.com>
* @license http://www.gnu.org/licenses/
*/

	// draw title bar
	draw_title_bar(_CUSTOMERS); 
	
	draw_content_start();
	draw_important_message(_PAGE_NOT_EXISTS);
	draw_content_end();
	
?>