<?php

/**
 *	Class Admins
 *  -------------- 
 *  Description : encapsulates admins properties
 *  Updated	    : 20.10.2010
 *	Written by  : ApPHP
 *	
 *	PUBLIC:				  	STATIC:				 	PRIVATE:
 * 	------------------	  	---------------     	---------------
 * 	
 **/

class Admins extends Accounts {


}

?>