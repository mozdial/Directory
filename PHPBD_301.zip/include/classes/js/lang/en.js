Vocabulary = function (){

};

Vocabulary._MSG = {};
Vocabulary._MSG["alert_delete_record"] = "Are you sure you want to delete this record?";
