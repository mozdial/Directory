/* English (en) */

RatingsVoc = function (){

};

RatingsVoc._MSG = {};
RatingsVoc._MSG["already_voted"] = "You have already voted! You can rate again tomorrow.";
RatingsVoc._MSG["thanks_for_rating"] = "Thanks for rating!";
RatingsVoc._MSG["votes"] = "votes";

