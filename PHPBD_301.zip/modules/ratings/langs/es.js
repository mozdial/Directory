/* Spanish (es) */

RatingsVoc = function (){

};

RatingsVoc._MSG = {};
RatingsVoc._MSG["already_voted"] = "Usted ya ha votado! Usted puede evaluar de nuevo mañana.";
RatingsVoc._MSG["thanks_for_rating"] = "¡Gracias por votar!";
RatingsVoc._MSG["votes"] = "votos";
