/* French (fr) */

RatingsVoc = function (){

};

RatingsVoc._MSG = {};
RatingsVoc._MSG["already_voted"] = "Vous avez déjà voté! Vous pouvez évaluer à nouveau demain.";
RatingsVoc._MSG["thanks_for_rating"] = "Merci pour votre évaluation!";
RatingsVoc._MSG["votes"] = "votes";

