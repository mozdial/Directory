/* Italian (it) */

RatingsVoc = function (){

};

RatingsVoc._MSG = {};
RatingsVoc._MSG["already_voted"] = "Hai già votato! Si possono votare anche domani.";
RatingsVoc._MSG["thanks_for_rating"] = "Grazie per il voto!";
RatingsVoc._MSG["votes"] = "voti";

