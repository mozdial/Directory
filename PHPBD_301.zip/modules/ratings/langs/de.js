/* German (de) */

RatingsVoc = function (){

};

RatingsVoc._MSG = {};
RatingsVoc._MSG["already_voted"] = "Du hast bereits abgestimmt! Sie können sich morgen wieder.";
RatingsVoc._MSG["thanks_for_rating"] = "Danke für Ihre Meinung!";
RatingsVoc._MSG["votes"] = "Stimmen";
