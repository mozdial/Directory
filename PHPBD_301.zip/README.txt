################################################################################
##              -= YOU MAY NOT REMOVE OR CHANGE THIS NOTICE =-                 #
## --------------------------------------------------------------------------- #
##  ApPHP Business Directory Pro version 3.0.1                                 #
##  Developed by:  ApPHP <info@apphp.com>                                      #
##  License:       GNU LGPL v.3                                                #
##  Site:          http://www.apphp.com/php-business-directory/                #
##  Copyright:     ApPHP Business Directory (c) 2010-2013. All rights reserved #
##                                                                             #
##  Additional modules (embedded):                                             #
##  -- ApPHP EasyInstaller v2.0.5 (installation module)       http://apphp.com #
##  -- ApPHP Tabs v2.0.3 (tabs menu control)        		  http://apphp.com #
##  -- ApPHP TreeMenu v2.0.1 (tree menu control)              http://apphp.com #
##  -- openWYSIWYG v1.4.7 (WYSIWYG editor)              http://openWebWare.com #
##  -- TinyMCE (WYSIWYG editor)                   http://tinymce.moxiecode.com #
##  -- Crystal Project Icons (icons set)               http://www.everaldo.com #
##  -- Securimage v2.0 BETA (captcha script)         http://www.phpcaptcha.org #
##  -- jQuery 1.4.2 (New Wave Javascript)                    http://jquery.com #
##  -- Google AJAX Libraries API                  http://code.google.com/apis/ #
##  -- Lytebox v3.22                                       http://lytebox.com/ #
##  -- JsCalendar v1.0 (DHTML/JavaScript Calendar)      http://www.dynarch.com #
##  -- RokBox System 			                   http://www.rockettheme.com/ #
##  -- VideoBox	  		                   http://videobox-lb.sourceforge.net/ #
##  -- CrossSlide jQuery plugin v0.6.2 	                     by Tobia Conforto #
##  -- PHPMailer v5.2 https://code.google.com/a/apache-extras.org/p/phpmailer/ #
##  -- Ajax-PHP Rating Stars Script                     http://coursesweb.net/ #
##                                                                             #
################################################################################


Thank you for using ApPHP.com software!
-----------------------------------------------------------------------------------

It's very easy to get started with ApPHP Business Directory!!!

1. Installation:
   http://apphp.com/php-business-directory/index.php?page=installation 
   or docs/Installation.htm

2. Getting Started:
   http://apphp.com/php-business-directory/index.php?page=getting-started
   or docs/Getting Started.htm


If you have any troubles, find an example of code in the folder, named "examples" 
-----------------------------------------------------------------------------------
For more information visit: 
	site 	http://apphp.com/php-business-directory/index.php?page=examples
	forum 	http://www.apphp.net/forum/
